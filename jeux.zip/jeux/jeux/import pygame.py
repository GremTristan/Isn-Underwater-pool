import pygame
import time
pygame.init()


t = (255,255,255,.4)
blue = (113,122,255)
white =(255,255,255) 
horloge = pygame.time.Clock()

win = pygame.display.set_mode((1920,980))
pygame.display.set_caption("Underwater ")

icon = pygame.image.load('img/plastic.png')  ## icone et nom  de la fênetre
pygame.display.set_icon(icon)

## image pour l'animation du perosnnage (Enormément d'image en double normal pour évité une erreur d'indexage)
x=400
y=600

x_perso = 400
y_perso = 600
persoW = 40
persoH = 60
vitesse = 10


walkLeft= [pygame.image.load('img/1.png'), pygame.image.load('img/2.png'), pygame.image.load('img/3.png'), pygame.image.load('img/4.png'), pygame.image.load('img/5.png'), pygame.image.load('img/6.png'), pygame.image.load('img/2.png'), pygame.image.load('img/3.png'), pygame.image.load('img/4.png'), pygame.image.load('img/5.png'), pygame.image.load('img/6.png'), pygame.image.load('img/2.png'), pygame.image.load('img/3.png'), pygame.image.load('img/4.png'), pygame.image.load('img/5.png'), pygame.image.load('img/6.png'), pygame.image.load('img/2.png'), pygame.image.load('img/3.png'), pygame.image.load('img/4.png'), pygame.image.load('img/5.png'), pygame.image.load('img/6.png'),pygame.image.load('img/1.png'), pygame.image.load('img/2.png'), pygame.image.load('img/3.png'), pygame.image.load('img/4.png'), pygame.image.load('img/5.png'), pygame.image.load('img/6.png'), pygame.image.load('img/2.png'), pygame.image.load('img/3.png'), pygame.image.load('img/4.png'), pygame.image.load('img/5.png'), pygame.image.load('img/6.png'), pygame.image.load('img/2.png'), pygame.image.load('img/3.png'), pygame.image.load('img/4.png'), pygame.image.load('img/5.png'), pygame.image.load('img/6.png'), pygame.image.load('img/2.png'), pygame.image.load('img/3.png'), pygame.image.load('img/4.png'), pygame.image.load('img/5.png'), pygame.image.load('img/6.png')]
walkRight = [pygame.image.load('img/L1.png'), pygame.image.load('img/L2.png'), pygame.image.load('img/L3.png'), pygame.image.load('img/L4.png'), pygame.image.load('img/L5.png'), pygame.image.load('img/L6.png'), pygame.image.load('img/L2.png'), pygame.image.load('img/L3.png'), pygame.image.load('img/L4.png'), pygame.image.load('img/L5.png'), pygame.image.load('img/L6.png'), pygame.image.load('img/L2.png'), pygame.image.load('img/L3.png'), pygame.image.load('img/L4.png'), pygame.image.load('img/L5.png'), pygame.image.load('img/L6.png'), pygame.image.load('img/L2.png'), pygame.image.load('img/L3.png'), pygame.image.load('img/L4.png'), pygame.image.load('img/L5.png'), pygame.image.load('img/L6.png'),pygame.image.load('img/L1.png'), pygame.image.load('img/L2.png'), pygame.image.load('img/L3.png'), pygame.image.load('img/L4.png'), pygame.image.load('img/L5.png'), pygame.image.load('img/L6.png'), pygame.image.load('img/L2.png'), pygame.image.load('img/L3.png'), pygame.image.load('img/L4.png'), pygame.image.load('img/L5.png'), pygame.image.load('img/L6.png'), pygame.image.load('img/L2.png'), pygame.image.load('img/L3.png'), pygame.image.load('img/L4.png'), pygame.image.load('img/L5.png'), pygame.image.load('img/L6.png'), pygame.image.load('img/L2.png'), pygame.image.load('img/L3.png'), pygame.image.load('img/L4.png'), pygame.image.load('img/L5.png'), pygame.image.load('img/L6.png')]
bg = pygame.image.load('img/background.jpg')
char = pygame.image.load('img/standing.png')
char_hit_box=pygame.Rect(10,10,50,50)
char_rect = pygame.draw.rect(char,blue,char_hit_box,2)







isJump = False
jumpCount = 10

left = False
right = False
walkCount = 0


## bateau qui est de 100/200
NavirW = 1100
NavirH = 900
vitesse_navire = 10
x_navir = 200
y_navir = 5
espace = 3

navire = pygame.image.load('img/NAVIRE.png')
navir = pygame.transform.scale(navire,(NavirW,NavirH))
nav_hit_box=pygame.Rect(400,450,170,50)
nav_rect = pygame.draw.rect(navir,blue,nav_hit_box,2)







#########################################################____Fonction déplacement personnage principal____##################################################################################################
 
 
def game0ver ():

    message("Perdu!!!")
    
    
## Fontion qui parametre le texte police et texte

def creaTextObjet (texte , police):
    texteSurface = police.render(texte,True,white)
    return texteSurface, texteSurface.get_rect()




def rejouOuQuitte ():
    for event in pygame.event.get ([pygame.KEYDOWN, pygame.KEYUP, pygame.QUIT]):
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()
        elif event.type == pygame.KEYUP:
            continue
        return event.key
    return True



##Fontion qui crée les texte de game over et (appuyer pour rejouer ) indiquer la police et la taille , et crée l'apparition du message

def message (texte):
    GTexte = pygame.font.Font('font/Second.ttf',150)
    Ptexte = pygame.font.Font('font/Second.ttf ', 100)
    RetournerMenu = pygame.font.Font ('font/Second.ttf ',150)


    GtexteSurf,GTexteRect = creaTextObjet (texte, GTexte)
    GTexteRect.center = 1920/2 , ((980/2)-50)
    win.blit(GtexteSurf, GTexteRect)
    PtexteSurf,PtexteRect = creaTextObjet("appuyer sur une touche pour continuer",Ptexte)
    PtexteRect.center = 1920 / 2 , ((980 / 2) + 50)
    win.blit ( PtexteSurf, PtexteRect )
    RetourMenuSurf,RetourMenuRect = creaTextObjet('Home',RetournerMenu)
    RetournerMenu= 1920 / 2 , ((980 /3) + 50)
    win.blit ( RetourMenuSurf, RetourMenuRect )
    pygame.display.update()
    time.sleep(4)
    while rejouOuQuitte() == True:
        horloge.tick()
        corps_game()


def mvt_pero():
    global NavirW
    global x_navir
    global y_navir
    global walkCount
    global x_perso
    global y_perso
    
    win.blit(bg, (0,0)) 
    win.blit(navir, (x_navir ,y_navir)) 
    x_navir -= vitesse


    if x_navir < (-0.5*NavirW):
        x_navir = 1920
    
    if walkCount + 1 >= 27:
        walkCount = 0
        
    if left:  
        win.blit(walkLeft[walkCount//3], (x_perso,y_perso))
        walkCount += 1                          
    elif right:
        win.blit(walkRight[walkCount//3], (x_perso,y_perso))
        walkCount += 1
    else:
        win.blit(char, (x_perso, y_perso))
        walkCount = 0
    






##Fonction pour parametrer et afficher les bateau

   

#############################################___LOOOOOOOOOOOOOOOOOOOOOP____#################################################################################



def corps_game():
    global x
    global y
    global X
    global Y
    global y_perso
    global x_perso
    global persoH
    global persoW
    global x_navir
    global y_navir
    global NavirH
    global NavirW
    global vitesse 
    global left
    global right
    global jump
    global walkcount 
    global jumpCount
    global isJump
    global nav_hit_box
    global char_hit_box
    global char 
    global navir
    global nav_rect
    global char_rect
    
    
    run = True 
    
    while run :
        horloge.tick(27)
        Seconde_txt = pygame.font.SysFont('font/Second.ttf', 35)
        fps_text = Seconde_txt.render('FPS: {:.2f}'.format(horloge.get_fps()),True,white)
        fps_rect = fps_text.get_rect(topleft=(1780,920))
        
        pygame.time.set_timer(24, 1000)
        
        
        
       
        if pygame.sprite.collide_rect(nav_rect,char_rect):
               game0ver() 
    
        
       
            
        
        
        win.blit(fps_text, fps_rect)
        
        
        
        
        
        pygame.display.flip()
        
        
    
        
        if y_perso >= 920:
            y_perso= 919
        if x_perso > 1889:
            x_perso = 1887
     




        for event in pygame.event.get():
         if event.type == pygame.QUIT:
            run = False

        keys = pygame.key.get_pressed()

         
        if keys[pygame.K_UP] and x_perso > vitesse:
            y_perso-= vitesse
            left = False
            right = False
        
        if keys[pygame.K_DOWN] and x_perso > vitesse:
            y_perso += vitesse
            left = False
            right = False
        
        if keys[pygame.K_LEFT] and x_perso > vitesse: 
            x_perso -= vitesse
            left = True
            right = False

        elif keys[pygame.K_RIGHT] and x_perso < 1980 - vitesse :  
            x_perso += vitesse
            left = False
            right = True
        
        else: 
            left = False
            right = False
            walkCount = 0
        
        if not(isJump):
            if keys[pygame.K_SPACE]:
                isJump = True
                left = False
                right = False
                walkCount = 0
            if y_perso <= 500:
                y_perso = 499
        elif y_perso >= 920 :
                y_perso = 919 
        else:
            if jumpCount >= -10:
                y_perso -= (jumpCount * abs(jumpCount)) * 0.5
                jumpCount -= 1
            else: 
                jumpCount = 10
                isJump = False
        if event.type == 24:
            fps_text = Seconde_txt.render('FPS: {:.2f}'.format(horloge.get_fps()),True,white)
            fps_rect = fps_text.get_rect(topleft=(960,480)) 

        
        mvt_pero()
        
         
    
        pygame.display.update()
        
     
corps_game()
quit()
    
    
