import time
from random import *
import pygame
pygame.init()
clock = pygame.time.Clock()
FPS = 15  # This variable will define how many frames we update per second.

## load ressource (personnage , bateau , background )

blue = (113,122,255)
white =(255,255,255)




## personnage principale tortue taille 50/10
turtelW = 320
turtelH = 320

hugo= pygame.image.load('img/turtelDR.png')
tortue = pygame.transform.scale(hugo, (70, 50))
hugo1 = pygame.image.load('img/turtelDS.png')
tortue1 = pygame.transform.scale(hugo, (50, 30))




## bateau qui est de 100/200
NavirW = 200
NavirH = 300

navire = pygame.image.load('img/NAVIRE.png')
navir = pygame.transform.scale(navire,(700,550))




## definiton de la longueur de la fenetre
fenetreW = 1080
fenetreH = 720



bg = pygame.image.load('img/background.jpg')
bg2 = pygame.transform.scale(bg,(1080,880))
fenetre = pygame.display.set_mode((fenetreW,fenetreH))
horloge = pygame.time.Clock()
pygame.display.set_caption("Underwater")         ## nom de la fenetre
icon = pygame.image.load('img/plastic.png')
pygame.display.set_icon(icon)

rect = pygame.Rect((0, 0), (500, 600))  # First tuple is position, second is size.
image = pygame.Surface((32, 32))  # The tuple represent size.




## objet que le bateau jetera
objet1 =  pygame.image.load('img/objet.png')
objet = pygame.transform.scale(objet1,(600,500))
objetH =  100
objetW = 100





##Fonction pour parametrer et afficher les bateau

def bateau (x_bateau,y_bateau,espace):
    fenetre.blit(navir, (x_bateau ,y_bateau))




def objet_fire (x, y):
   fenetre.blit(objet, (x, y))






## Fonction pour quitter ou pour rejouer


def rejouOuQuitte ():
    for event in pygame.event.get ([pygame.KEYDOWN, pygame.KEYUP, pygame.QUIT]):
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()
        elif event.type == pygame.KEYUP:
            continue
        return event.key
    return True










## Fontion qui parametre le texte police et texte

def creaTextObjet (texte , police):
    texteSurface = police.render(texte,True,white)
    return texteSurface, texteSurface.get_rect()








##Fontion qui crée les texte de game over et (appuyer pour rejouer ) indiquer la police et la taille , et crée l'apparition du message

def message (texte):
    GTexte = pygame.font.Font('font/Second.ttf',150)
    Ptexte = pygame.font.Font('font/Second.ttf ', 100)
    RetournerMenu = pygame.font.Font ('font/Second.ttf ',150)


    GtexteSurf,GTexteRect = creaTextObjet (texte, GTexte)
    GTexteRect.center = fenetreW/2 , ((fenetreH/2)-50)
    fenetre.blit(GtexteSurf, GTexteRect)
    PtexteSurf,PtexteRect = creaTextObjet("appuyer sur une touche pour continuer",Ptexte)
    PtexteRect.center = fenetreW / 2 , ((fenetreH / 2) + 50)
    fenetre.blit ( PtexteSurf, PtexteRect )
    RetourMenuSurf,RetourMenuRect = creaTextObjet('Home',RetournerMenu)
    RetournerMenu= fenetreW / 2 , ((fenetreH /3) + 50)
    fenetre.blit ( RetourMenuSurf, RetourMenuRect )
    pygame.display.update()
    time.sleep(4)
    while rejouOuQuitte() ==True :
        horloge.tick()
        corps_game()















## Fonction lorsque l'on perd on appele la fonction message crée au dessus

def game0ver ():

    message("Perdu!!!")










## Fonction du personnage principal du jeux
def perso (x,y,image):

    fenetre.blit(image, (x, y))












## Fonction principale du jeux qui permet de mettre en lien les autres fonction et de parametrer les touches ect

def corps_game ():


    perso_x = 150
    perso_y = 400                  ## initie les coordonnées au seron afficher les images qui sont les personnages du jeux
    mvt_y = 0
    mvt_x = 0
    navir_x = 0
    navir_y = 100
    espace = perso_y*3
    vitesse = 3
    objet_x = 0
    objet_y = 80




    fin_game = False

    while not  fin_game :
        fenetre.blit(bg2 , (0, 0))
        pygame.display.flip()                         ## boucle du jeux ( tant que la valeur de fin_game ne passe pas en True alors afficher les fonctions
        perso ( perso_x, perso_y ,tortue )
        bateau(navir_x,navir_y,espace)
        objet_fire(navir_x,objet_y)


        if (x_perso > 340 and x_perso < 350) and (y_perso < y_navir + 40 and y_perso > y_navir -40):
            game0ver()

        if (x_perso < -340 and x_perso > -350) and (y_perso < y_navir + 40 and y_perso > y_navir -40):
            game0ver()



        navir_x -= vitesse


        if navir_x < (-3*NavirW):
            navir_x = fenetreW

        if perso_y <= 300 :
            perso_y = 300
        elif perso_y >= 690 :
            perso_y = 690 # condition qui dit que lorsque on atteint une hauteur superieur a 100 pixel on execute la fonction gameover  ou si le personnage et à 70 pixel

        if perso_x <= 0:
            perso_x = 0
        elif perso_x >= 1030:
            perso_x = 1030

        if navir_x == perso_x and navir_y == perso_y :
            game0ver ()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
               fin_game = True

            if event.type == pygame.KEYDOWN :
                if event.key == pygame.K_UP:
                    mvt_y = -4
                if event.key == pygame.K_DOWN :
                    mvt_y = +4
                if event.key == pygame.K_RIGHT :

                    mvt_x = +4
                if event.key == pygame.K_LEFT:
                    mvt_x -= 6

                if event.key == pygame.K_SPACE :
                    objet_y -= -10



                if event.key == pygame.K_LEFT :
                    mvt_x = -2
        perso_x+= mvt_x
        perso_y+= mvt_y





        pygame.display.update()
        
    clock.tick ( 20)
    pygame.quit()
corps_game()

quit()
