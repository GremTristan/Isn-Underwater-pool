import pygame 
blue = (113,122,255)

rect = (20,20,20,20)
rect1 =(20,20,20,20)

z = pygame.draw.rect(rect,blue,0,2)
z1 = pygame.draw.rect(rect1,blue,0,2)
